from flask import Flask, render_template, request #, redirect
app = Flask(__name__)

@app.route('/')
def index():
  return render_template("index.html")

@app.route('/result', methods=['POST'])
def process():
   print "Got Post Info"
   name = request.form['name']
   email = request.form['email']
   print name
   print email

   return render_template('/result.html', name = name, email = email)
app.run(debug=True) # run our server
