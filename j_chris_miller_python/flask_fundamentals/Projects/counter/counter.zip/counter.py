from flask import Flask, request, render_template, session, redirect
app = Flask(__name__)
app.secret_key = 'hello'

@app.route('/')
def index():	
	if 'hit' not in session:
		session['hit'] = 1
	else:
		session['hit'] += 1
	return render_template('index.html')

# @app.route('/')
# def hit():
# 	hit = session.get('hit')
# 	if not hit:
# 		request.session['hit'] = 1
# 	else:
# 		request.session['hit'] += 1
# 	return render_template('index.html')


app.run(debug = True)